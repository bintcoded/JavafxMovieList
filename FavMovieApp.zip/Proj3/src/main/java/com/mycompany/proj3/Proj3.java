
//Sara Al-Hachami
// CIS 2353
// Summer 2025
//Prof. John P. Baugh


package com.mycompany.proj3;

import java.io.IOException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Proj3 extends javafx.application.Application {

    private final Path filePath = Paths.get("movies.txt");
    private ListView<String> movieList;
    private ObservableList<String> items;
    private TextField input;

    public static void main(String[] args) { launch(args); }

    @Override
    public void start(Stage stage) {
        stage.setTitle("Favorite Movies");

        items = FXCollections.observableArrayList();
        movieList = new ListView<>(items);
        movieList.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE); // multi-select delete

        input = new TextField();
        input.setPromptText("Type a movie title...");
        Button addBtn = new Button("Add");
        addBtn.setDefaultButton(true);
        addBtn.setOnAction(e -> addMovie());
        input.setOnKeyPressed(e -> { if (e.getCode() == KeyCode.ENTER) addMovie(); });

        HBox inputRow = new HBox(8, input, addBtn);
        inputRow.setAlignment(Pos.CENTER_LEFT);

        Button removeBtn = new Button("Remove");  removeBtn.setOnAction(e -> removeSelected());
        Button loadBtn   = new Button("Load");    loadBtn.setOnAction(e -> loadFromFile());
        Button saveBtn   = new Button("Save");    saveBtn.setOnAction(e -> saveToFile());
        HBox actions = new HBox(10, removeBtn, loadBtn, saveBtn);
        actions.setAlignment(Pos.CENTER_RIGHT);

        VBox root = new VBox(12, new Label("List of Movies"), movieList, inputRow, actions);
        root.setPadding(new Insets(14));
        VBox.setVgrow(movieList, Priority.ALWAYS);

        stage.setScene(new Scene(root, 520, 420));
        stage.show();
    }

    private void addMovie() {
        String text = input.getText();
        String cleaned = (text == null ? "" : text).trim().toLowerCase(); // trim + lowercase
        if (cleaned.isEmpty()) {
            info("Empty Input", "Please type a movie title before adding.");
            return;
        }
        items.add(cleaned);
        input.clear();
        input.requestFocus();
    }

    private void removeSelected() {
        ObservableList<Integer> sel = movieList.getSelectionModel().getSelectedIndices();
        if (sel == null || sel.isEmpty()) {
            info("Remove", "Please select an item to delete!");
            return;
        }
        List<Integer> idx = new ArrayList<>(sel);
        Collections.sort(idx, Collections.reverseOrder()); // delete from end
        for (int i : idx) items.remove(i);
    }

    private void loadFromFile() {
        try {
            if (!Files.exists(filePath)) {
                info("Load", "No saved list found yet. (movies.txt will be created when you Save.)");
                return;
            }
            List<String> lines = Files.readAllLines(filePath, StandardCharsets.UTF_8);
            items.setAll(lines);
            info("Load", "Movie list loaded.");
        } catch (IOException ex) {
            error("Load Error", ex.getMessage());
        }
    }

    private void saveToFile() {
        try {
            Files.write(filePath, items, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
            info("Save", "Movie list saved to movies.txt");
        } catch (IOException ex) {
            error("Save Error", ex.getMessage());
        }
    }

    private void info(String t, String m) {
        Alert a = new Alert(Alert.AlertType.INFORMATION, m, ButtonType.OK);
        a.setTitle(t); a.setHeaderText(null); a.showAndWait();
    }

    private void error(String t, String m) {
        Alert a = new Alert(Alert.AlertType.ERROR, m, ButtonType.OK);
        a.setTitle(t); a.setHeaderText(null); a.showAndWait();
    }
}