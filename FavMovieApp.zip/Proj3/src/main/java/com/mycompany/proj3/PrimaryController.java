//Sara Al-Hachami
// CIS 2353
// Summer 2025
//Prof. John P. Baugh

package com.mycompany.proj3;

import java.io.IOException;
import javafx.fxml.FXML;

public class PrimaryController {

    @FXML
    private void switchToSecondary() throws IOException {
        App.setRoot("secondary");
    }
}
