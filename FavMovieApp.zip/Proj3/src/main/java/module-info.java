//Sara Al-Hachami
// CIS 2353
// Summer 2025
//Prof. John P. Baugh

module com.mycompany.proj3 {
    requires javafx.controls;
    requires javafx.fxml;
    exports com.mycompany.proj3;
    opens com.mycompany.proj3 to javafx.fxml;
}
